export type Level = "beginner" | "intermediate" | "advanced"

export type Course = {
  title: string
  instructor: string
  description: string
  videoId: string
  listId?: string
  type: string
  isNew?: boolean
}

export type Track = {
  id: string
  title: string
  subtitle: string
  level: Level
  description: string
  courses: Course[]
}

export type Channel = {
  name: string
  handle: string
  description: string
  lang: "ar" | "en"
}

export const LEVELS: Record<Level, { label: string; code: string }> = {
  beginner: { label: "مبتدئ", code: "LVL_01" },
  intermediate: { label: "متوسط", code: "LVL_02" },
  advanced: { label: "متقدم", code: "LVL_03" },
}

export const TRACKS: Track[] = [
  {
    id: "fundamentals",
    title: "أساسيات الأمن السيبراني",
    subtitle: "Fundamentals",
    level: "beginner",
    description: "ابدأ رحلتك بتعلم أساسيات الحاسوب ومبادئ الأمان.",
    courses: [
      {
        title: "أساسيات الأمن السيبراني",
        instructor: "Yasser Ammar",
        description: "نقطة البداية المثالية: سلسلة عربية مختصرة تشرح المفاهيم الجوهرية للأمن السيبراني بأسلوب واضح للمبتدئين.",
        videoId: "8CUwUXMgOQ4",
        listId: "PLj6pcGpLuSKMMSXy_RE_TRitc-Ez_LXww",
        type: "سلسلة يوتيوب · 8 دروس",
        isNew: true,
      },
      {
        title: "دورة CompTIA A+",
        instructor: "سامح رمضان",
        description: "دورة أساسيات الحاسوب العامة - تغطي كل ما تحتاجه لفهم أساسيات الحاسوب والأجهزة.",
        videoId: "zIpF33NCgrA",
        listId: "PLH-n8YK76vIiDdOMRB-ylvns-_8Zl1euV",
        type: "سلسلة يوتيوب",
      },
      {
        title: "دورة Security+",
        instructor: "أحمد سلطان",
        description: "أساسيات الأمان مناسبة للمبتدئين - دورة شاملة لفهم مبادئ الأمن السيبراني.",
        videoId: "dyKg_bQOXfU",
        listId: "PLky4bd7_03m8o1NB0j96OsxZs0KcKlgMO",
        type: "سلسلة يوتيوب",
      },
    ],
  },
  {
    id: "networking",
    title: "الشبكات",
    subtitle: "Networking",
    level: "beginner",
    description: "تعلم TCP/IP ونموذج OSI والبروتوكولات الأساسية التي يحتاجها كل متخصص.",
    courses: [
      {
        title: "دورة Network+",
        instructor: "سامح رمضان",
        description: "دورة شاملة لشهادة CompTIA Network+ باللغة العربية تغطي نموذج OSI وبروتوكولات TCP/IP.",
        videoId: "RFK4Kc_aJYg",
        listId: "PLH-n8YK76vIiuIZoWvHL7AvtrDV7hR3He",
        type: "سلسلة يوتيوب",
      },
      {
        title: "دورة CCNA",
        instructor: "NetworkChuck",
        description: "أساسيات شهادة CCNA - دورة ممتعة ومفيدة جداً قبل التعمق في الشبكات والأمن السيبراني.",
        videoId: "S7MNX_UD7vY",
        listId: "PLIhvC56v63IJVXv0GJcl9vO5Z6znCVb1P",
        type: "سلسلة يوتيوب",
      },
      {
        title: "دورة CCNA بالعربي",
        instructor: "م. وليد سعد الدين",
        description: "دورة قوية ومبسطة في الشبكات، مناسبة للمبتدئين لفهم المفاهيم الأساسية قبل دخول المجال.",
        videoId: "JaLlJ2hUXC8",
        listId: "PLLlr6jKKdyK2cNjQnBcSfGab2k9KNsUmg",
        type: "سلسلة يوتيوب",
      },
    ],
  },
  {
    id: "linux",
    title: "نظام لينكس",
    subtitle: "Linux",
    level: "beginner",
    description: "سلاح كل مختبر اختراق. تعلم الأوامر والمهارات الأساسية للتعامل مع النظام.",
    courses: [
      {
        title: "أساسيات نظام لينكس",
        instructor: "دورة عربية",
        description: "دورة شاملة في أساسيات لينكس للمبتدئين تشرح أهم الأوامر والمهارات الأساسية.",
        videoId: "ZVAddIMB3mg",
        listId: "PLDRMxi70CdSD48OPJbsDZRt4l0GvWJ2iG",
        type: "سلسلة يوتيوب",
      },
    ],
  },
  {
    id: "programming",
    title: "البرمجة وبايثون",
    subtitle: "Programming",
    level: "beginner",
    description: "البرمجة أساس فهم كيفية عمل الأنظمة واكتشاف الثغرات وبناء أدواتك الخاصة.",
    courses: [
      {
        title: "أساسيات لغة Python",
        instructor: "أسامة الزيرو",
        description: "دورة شاملة لتعلم أساسيات لغة بايثون من الصفر.",
        videoId: "mvZHDpCHphk",
        listId: "PLDoPjvoNmBAyE_gei5d18qkfIe-Z8mocs",
        type: "سلسلة يوتيوب",
      },
      {
        title: "بايثون للأمن السيبراني",
        instructor: "م. راكوان",
        description: "بناء أدوات الاختراق ببايثون - دورة متخصصة لتعلم كتابة أدوات الأمن السيبراني.",
        videoId: "KMOS1aPgpgo",
        listId: "PLQecpJ5wKrfsF7mZVJxvy53I7FimkGxzZ",
        type: "سلسلة يوتيوب",
      },
    ],
  },
  {
    id: "ethical-hacking",
    title: "الاختراق الأخلاقي",
    subtitle: "Ethical Hacking",
    level: "intermediate",
    description: "دورات عربية شاملة في الاختراق الأخلاقي من الأساسيات حتى الاستغلال.",
    courses: [
      {
        title: "دورة الاختراق الأخلاقي",
        instructor: "Coder Web",
        description: "دورة شاملة للاختراق الأخلاقي باللغة العربية تغطي الأساسيات والتقنيات المتقدمة.",
        videoId: "IyxgtWKtzQw",
        listId: "PLMuAdKgHarVrcZCqzJFdNlTiKz66U19Xk",
        type: "سلسلة كاملة",
      },
      {
        title: "الهاكر الأخلاقي في 6 ساعات",
        instructor: "أكاديمية صحيح",
        description: "دورة مكثفة لتعلم أساسيات الاختراق الأخلاقي في 6 ساعات فقط.",
        videoId: "qaNZKH5NohQ",
        type: "دورة مكثفة",
      },
      {
        title: "اكتشاف ثغرات المواقع",
        instructor: "أكاديمية صحيح",
        description: "تعلم كيفية اكتشاف ثغرات المواقع بطريقة احترافية ومنهجية.",
        videoId: "b_EGEerEqvA",
        type: "دورة متقدمة",
      },
      {
        title: "اختبار الاختراق بـ Metasploit",
        instructor: "أكاديمية صحيح",
        description: "تعلم استخدام أداة Metasploit لاختبار الاختراق والاستغلال.",
        videoId: "uThOnvh1zJw",
        type: "دورة تخصصية",
      },
    ],
  },
  {
    id: "pentest",
    title: "اختبار الاختراق",
    subtitle: "Penetration Testing",
    level: "intermediate",
    description: "استعد لشهادات OSCP مع أقوى المصادر العربية في اختبار الاختراق الاحترافي.",
    courses: [
      {
        title: "دورة OSCP",
        instructor: "أحمد عطية",
        description: "دورة OSCP الكاملة لإتقان اختبار الاختراق.",
        videoId: "bc8JcenrvB0",
        listId: "PLZNz7wrFA85CHJLogfqUJJUg2EkxvIa27",
        type: "سلسلة يوتيوب",
      },
      {
        title: "دورة OSCP+",
        instructor: "أحمد عطية",
        description: "دورة OSCP+ المتقدمة لاختبار الاختراق الاحترافي.",
        videoId: "VAV0Z8GGT9g",
        listId: "PL5dZpxpUkHPM0HMefFCFjGeLAwyty4LYm",
        type: "سلسلة يوتيوب",
      },
    ],
  },
  {
    id: "web-dev",
    title: "برمجة الويب للمختبر",
    subtitle: "Web Foundations",
    level: "intermediate",
    description: "HTML و JavaScript و PHP - افهم بنية المواقع قبل أن تختبر اختراقها.",
    courses: [
      {
        title: "دورة HTML",
        instructor: "أسامة الزيرو",
        description: "أساسيات HTML لفهم هيكلة صفحات الويب.",
        videoId: "6QAELgirvjs",
        listId: "PLDoPjvoNmBAw_t_XWUFbBX-c9MafPk9ji",
        type: "سلسلة يوتيوب",
      },
      {
        title: "دورة JavaScript",
        instructor: "أسامة الزيرو",
        description: "أساسيات JavaScript - الخطوة الأولى لفهم الجانب التفاعلي للمواقع.",
        videoId: "GM6dQBmc-Xg",
        listId: "PLDoPjvoNmBAx3kiplQR_oeDqLDBUDYwVv",
        type: "سلسلة يوتيوب",
      },
      {
        title: "دورة PHP",
        instructor: "أسامة الزيرو",
        description: "أساسيات PHP لبرمجة الخوادم وفهم الجانب الخلفي للمواقع.",
        videoId: "xcg9qq6SZ0w",
        listId: "PLDoPjvoNmBAy41u35AqJUrI-H83DObUDq",
        type: "سلسلة يوتيوب",
      },
    ],
  },
  {
    id: "web-pentest",
    title: "اختبار اختراق الويب",
    subtitle: "Web Pentesting",
    level: "advanced",
    description: "ثغرات تطبيقات الويب من XSS إلى SQLi وطرق استغلالها واكتشافها.",
    courses: [
      {
        title: "اختبار اختراق الويب",
        instructor: "م. إبراهيم حجازي",
        description: "كورس لتعلم أساسيات اختبار اختراق الويب للمهندس الكبير إبراهيم حجازي.",
        videoId: "BjfCWSFmIFI",
        listId: "PLFp3U4AOU6ACPUGth26yLFOMNIVuE67u4",
        type: "سلسلة يوتيوب",
      },
      {
        title: "أساسيات اختبار اختراق الويب",
        instructor: "تكناوي دوت نت",
        description: "كورس أساسيات اختبار اختراق الويب للمبتدئين.",
        videoId: "clLoyQeEVUw",
        listId: "PLroS9tRyoUGpAJPAgygxEP9imIZpkxFMi",
        type: "سلسلة يوتيوب",
      },
    ],
  },
  {
    id: "active-directory",
    title: "Active Directory",
    subtitle: "AD Attacks",
    level: "advanced",
    description: "افهم بيئات Windows المؤسسية وكيف يتم اختراقها.",
    courses: [
      {
        title: "Active Directory 101",
        instructor: "إيهاب أبو عليا",
        description: "دورة شاملة لفهم Active Directory من الصفر.",
        videoId: "l5jryNnDhjk",
        listId: "PLyyAUp-Erl9WhBzp1ma2NzYQEb1nfQM1t",
        type: "سلسلة يوتيوب",
      },
    ],
  },
  {
    id: "malware",
    title: "تحليل البرمجيات الخبيثة",
    subtitle: "Blue Team",
    level: "advanced",
    description: "الهندسة العكسية وتحليل البرمجيات الخبيثة - انتقل إلى جانب الدفاع.",
    courses: [
      {
        title: "Malware Analysis",
        instructor: "م. إسلام عباس",
        description: "كورس شامل لتعلم تحليل البرمجيات الخبيثة والهندسة العكسية باللغة العربية.",
        videoId: "6P8N7VW21MQ",
        listId: "PLgKWvRMsdLZ4N_okwVWqB6cgqeVQtZNC4",
        type: "سلسلة يوتيوب",
      },
    ],
  },
]

export const CHANNELS: Channel[] = [
  { name: "Azzam Sec", handle: "azzamsec", description: "محتوى عربي في الأمن السيبراني وخرائط التعلم.", lang: "ar" },
  { name: "ArabSecLab", handle: "Arabseclab", description: "شروحات عربية قوية وعملية في اختبار اختراق الويب.", lang: "ar" },
  { name: "NetworkChuck", handle: "NetworkChuck", description: "قناة رائعة لتعلم الشبكات والأمن السيبراني بطريقة ممتعة.", lang: "en" },
  { name: "John Hammond", handle: "_JohnHammond", description: "محتوى متنوع في الأمن السيبراني و CTF والبرمجة.", lang: "en" },
  { name: "IppSec", handle: "ippsec", description: "شروحات تفصيلية لحل تحديات Hack The Box.", lang: "en" },
  { name: "HackerSploit", handle: "HackerSploit", description: "دروس في اختبار الاختراق والأمن السيبراني.", lang: "en" },
  { name: "The Cyber Mentor", handle: "TCMSecurityAcademy", description: "دورات شاملة في اختبار الاختراق الأخلاقي.", lang: "en" },
  { name: "LiveOverflow", handle: "LiveOverflow", description: "محتوى متقدم في أمن التطبيقات والثغرات.", lang: "en" },
  { name: "STÖK", handle: "STOKfredrik", description: "Bug bounty hunting والأمن السيبراني.", lang: "en" },
  { name: "NahamSec", handle: "NahamSec", description: "نصائح Bug bounty وشروحات أمن الويب.", lang: "en" },
]

export function courseUrl(c: Course) {
  return c.listId
    ? `https://www.youtube.com/watch?v=${c.videoId}&list=${c.listId}`
    : `https://www.youtube.com/watch?v=${c.videoId}`
}

export function embedUrl(c: Course) {
  const base = `https://www.youtube-nocookie.com/embed/${c.videoId}?autoplay=1&rel=0`
  return c.listId ? `${base}&list=${c.listId}` : base
}

export function thumbUrl(c: Course) {
  return `https://i.ytimg.com/vi/${c.videoId}/hqdefault.jpg`
}

export const TOTAL_COURSES = TRACKS.reduce((n, t) => n + t.courses.length, 0)

export const FEATURED_COURSE = TRACKS[0].courses[0]
