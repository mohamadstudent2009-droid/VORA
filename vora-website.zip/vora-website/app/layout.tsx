import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Alexandria, JetBrains_Mono } from 'next/font/google'
import './globals.css'

const arabic = Alexandria({
  subsets: ['arabic', 'latin'],
  weight: ['300', '400', '500', '600', '700', '800'],
  variable: '--font-arabic',
})

const mono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono-en',
})

export const metadata: Metadata = {
  title: 'VORA | أكاديمية الأمن السيبراني المجانية',
  description:
    'VORA: خارطة طريق عربية مجانية لتعلم الأمن السيبراني من الصفر حتى الاحتراف عبر أفضل دورات يوتيوب في الشبكات ولينكس والبرمجة واختبار الاختراق.',
  generator: 'v0.app',
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#06080a',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl" className={`${arabic.variable} ${mono.variable} bg-background`}>
      <body className="font-sans antialiased">
        <div aria-hidden="true" className="noise pointer-events-none fixed inset-0 z-[60] opacity-[0.035] mix-blend-overlay" />
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
