import { Channels } from "@/components/channels"
import { CourseExplorer } from "@/components/course-explorer"
import { FeaturedCourse } from "@/components/featured-course"
import { Hero } from "@/components/hero"
import { PlayerProvider } from "@/components/player-provider"
import { Roadmap } from "@/components/roadmap"
import { SiteFooter } from "@/components/site-footer"
import { SiteHeader } from "@/components/site-header"

export default function Page() {
  return (
    <PlayerProvider>
      <SiteHeader />
      <main>
        <Hero />
        <FeaturedCourse />
        <Roadmap />
        <CourseExplorer />
        <Channels />
      </main>
      <SiteFooter />
    </PlayerProvider>
  )
}
