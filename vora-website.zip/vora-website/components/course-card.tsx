"use client"

import Image from "next/image"
import { ExternalLink, Play } from "lucide-react"
import { usePlayer } from "@/components/player-provider"
import { courseUrl, thumbUrl, type Course } from "@/lib/courses"
import { cn } from "@/lib/utils"

export function CourseCard({ course }: { course: Course }) {
  const play = usePlayer()

  return (
    <article
      className={cn(
        "group flex flex-col overflow-hidden rounded-3xl border border-border bg-card/60 p-2 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-2xl hover:shadow-primary/10",
        course.isNew && "card-glow",
      )}
    >
      <button
        type="button"
        onClick={() => play(course)}
        className="relative block aspect-video overflow-hidden rounded-2xl bg-muted"
        aria-label={`تشغيل ${course.title}`}
      >
        <Image
          src={thumbUrl(course) || "/placeholder.svg"}
          alt=""
          fill
          unoptimized
          sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <span className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-60 transition-opacity group-hover:opacity-90" />
        <span className="absolute inset-0 grid place-items-center opacity-0 transition-opacity group-hover:opacity-100">
          <span className="grid size-14 place-items-center bg-gold rounded-full text-primary-foreground shadow-xl shadow-primary/50">
            <Play className="size-5 fill-current" aria-hidden="true" />
          </span>
        </span>
        <span className="absolute start-3 top-3 flex gap-2">
          {course.isNew && (
            <span className="rounded-full bg-tertiary px-2.5 py-1 text-xs font-bold text-background">جديد</span>
          )}
          <span className="rounded-full bg-background/80 px-2.5 py-1 text-xs text-foreground backdrop-blur">{course.type}</span>
        </span>
      </button>

      <div className="flex flex-1 flex-col px-3 pt-4 pb-2">
        <p className="text-xs font-medium text-secondary" dir="auto">{course.instructor}</p>
        <h4 className="mt-1.5 text-lg leading-snug font-bold" dir="auto">{course.title}</h4>
        <p className="mt-2 line-clamp-2 flex-1 text-sm leading-relaxed text-muted-foreground">{course.description}</p>

        <div className="mt-5 flex gap-2">
          <button
            type="button"
            onClick={() => play(course)}
            className="inline-flex h-10 flex-1 items-center justify-center gap-2 rounded-xl bg-foreground text-sm font-semibold text-background transition-opacity hover:opacity-90"
          >
            <Play className="size-4 fill-current" aria-hidden="true" />
            شاهد الآن
          </button>
          <a
            href={courseUrl(course)}
            target="_blank"
            rel="noopener noreferrer"
            className="grid size-10 place-items-center rounded-xl border border-border text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            aria-label={`فتح ${course.title} على يوتيوب`}
          >
            <ExternalLink className="size-4" aria-hidden="true" />
          </a>
        </div>
      </div>
    </article>
  )
}
