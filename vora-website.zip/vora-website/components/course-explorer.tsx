"use client"

import { useMemo, useState } from "react"
import { Search } from "lucide-react"
import { CourseCard } from "@/components/course-card"
import { SectionHeading } from "@/components/section-heading"
import { LEVELS, TRACKS, type Level } from "@/lib/courses"
import { cn } from "@/lib/utils"

type Filter = "all" | Level

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "الكل" },
  { id: "beginner", label: LEVELS.beginner.label },
  { id: "intermediate", label: LEVELS.intermediate.label },
  { id: "advanced", label: LEVELS.advanced.label },
]

const LEVEL_BADGE: Record<Level, string> = {
  beginner: "border-secondary/30 bg-secondary/10 text-secondary",
  intermediate: "border-primary/30 bg-primary/10 text-primary",
  advanced: "border-tertiary/30 bg-tertiary/10 text-tertiary",
}

export function CourseExplorer() {
  const [filter, setFilter] = useState<Filter>("all")
  const [query, setQuery] = useState("")

  const tracks = useMemo(() => {
    const q = query.trim().toLowerCase()
    return TRACKS.map((t, i) => ({ ...t, index: i + 1 }))
      .filter((t) => filter === "all" || t.level === filter)
      .map((t) => ({
        ...t,
        courses: q
          ? t.courses.filter((c) =>
              [c.title, c.instructor, c.description, t.title, t.subtitle].join(" ").toLowerCase().includes(q),
            )
          : t.courses,
      }))
      .filter((t) => t.courses.length > 0)
  }, [filter, query])

  const count = tracks.reduce((n, t) => n + t.courses.length, 0)

  return (
    <section id="courses" className="scroll-mt-24 py-24">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeading
          eyebrow="مكتبة الدورات"
          title="كل ما تحتاجه، في مكان واحد"
          description="شاهد الدورات مباشرة داخل VORA أو افتح السلسلة كاملة على يوتيوب. جميعها مجانية وتدعم صنّاع المحتوى."
        />

        <div className="sticky top-20 z-30 mt-10 flex flex-col gap-3 rounded-2xl border border-border bg-background/80 p-2 backdrop-blur-xl sm:flex-row sm:items-center">
          <label className="relative block flex-1">
            <span className="sr-only">ابحث عن دورة</span>
            <Search className="pointer-events-none absolute start-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن دورة، مدرب أو موضوع..."
              className="h-11 w-full rounded-xl bg-card ps-10 pe-4 text-sm outline-none placeholder:text-muted-foreground focus:ring-2 focus:ring-ring/40"
            />
          </label>
          <div role="group" aria-label="تصفية حسب المستوى" className="flex gap-1">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                aria-pressed={filter === f.id}
                onClick={() => setFilter(f.id)}
                className={cn(
                  "h-11 flex-1 rounded-xl px-4 text-sm font-medium transition-colors sm:flex-none",
                  filter === f.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-foreground",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        <p className="mt-6 text-sm text-muted-foreground" aria-live="polite">
          {count} دورة متاحة
        </p>

        <div className="mt-8 flex flex-col gap-20">
          {tracks.map((t) => (
            <div key={t.id} id={`track-${t.id}`} className="scroll-mt-40">
              <div className="mb-8 flex flex-wrap items-center gap-5">
                <span className="font-mono text-5xl font-bold text-foreground/10" aria-hidden="true">
                  {String(t.index).padStart(2, "0")}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-3">
                    <h3 className="text-2xl font-bold">{t.title}</h3>
                    <span className={cn("rounded-full border px-2.5 py-0.5 text-xs font-medium", LEVEL_BADGE[t.level])}>
                      {LEVELS[t.level].label}
                    </span>
                  </div>
                  <p className="mt-1.5 text-muted-foreground">{t.description}</p>
                </div>
              </div>
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {t.courses.map((c) => (
                  <CourseCard key={c.videoId} course={c} />
                ))}
              </div>
            </div>
          ))}

          {tracks.length === 0 && (
            <div className="rounded-3xl border border-dashed border-border p-16 text-center">
              <p className="text-lg font-semibold">لا توجد نتائج</p>
              <p className="mt-2 text-muted-foreground">جرّب كلمة بحث أخرى أو غيّر المستوى.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
