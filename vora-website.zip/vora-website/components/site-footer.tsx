import { ArrowLeft } from "lucide-react"
import { VoraLogo } from "@/components/vora-logo"

export function SiteFooter() {
  return (
    <footer className="px-4 pb-8">
      <div className="relative mx-auto max-w-6xl overflow-hidden rounded-[2rem] border border-border bg-card/50 px-6 py-16 text-center md:px-12">
        <div aria-hidden="true" className="absolute inset-x-0 -bottom-32 mx-auto h-64 w-2/3 rounded-full bg-primary/30 blur-[100px]" />
        <div className="relative">
          <h2 className="text-3xl font-extrabold text-balance md:text-4xl">
            رحلتك تبدأ <span className="text-gradient">بخطوة واحدة</span>
          </h2>
          <p className="mx-auto mt-4 max-w-lg text-muted-foreground text-pretty">
            ابدأ بدورة الأساسيات اليوم، والتزم بساعة يومياً. بعد أشهر ستتفاجأ بما وصلت إليه.
          </p>
          <a
            href="#courses"
            className="group mt-8 inline-flex h-12 items-center gap-2 bg-gold rounded-xl px-6 font-bold text-primary-foreground shadow-lg shadow-primary/30"
          >
            ابدأ التعلم الآن
            <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" aria-hidden="true" />
          </a>
        </div>
      </div>

      <div className="mx-auto mt-8 flex max-w-6xl flex-col items-center justify-between gap-4 px-2 text-sm text-muted-foreground sm:flex-row">
        <VoraLogo />
        <p>جميع الدورات مملوكة لأصحابها على يوتيوب. VORA تنظّمها فقط.</p>
      </div>
    </footer>
  )
}
