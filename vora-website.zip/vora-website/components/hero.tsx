import Image from "next/image"
import { ArrowLeft, ShieldCheck } from "lucide-react"
import { CHANNELS, TOTAL_COURSES, TRACKS } from "@/lib/courses"

const STATS = [
  { value: TOTAL_COURSES, label: "دورة مختارة" },
  { value: TRACKS.length, label: "مسار تعليمي" },
  { value: CHANNELS.length, label: "قناة موصى بها" },
  { value: "0$", label: "التكلفة" },
]

export function Hero() {
  return (
    <section id="top" className="relative isolate flex min-h-[100svh] flex-col overflow-hidden pt-32">
      <Image
        src="/images/vora-hero.png"
        alt=""
        fill
        priority
        quality={100}
        sizes="100vw"
        className="-z-20 object-cover object-left opacity-90"
      />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-gradient-to-l from-background via-background/80 to-background/10" />
      <div aria-hidden="true" className="absolute inset-x-0 bottom-0 -z-10 h-48 bg-gradient-to-t from-background to-transparent" />
      <div aria-hidden="true" className="bg-grid mask-fade absolute inset-0 -z-10 opacity-60" />

      <div className="relative mx-auto flex w-full max-w-7xl flex-1 items-center px-5">
        <div className="max-w-2xl py-12">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-3.5 py-1.5 text-xs font-medium text-tertiary backdrop-blur">
            <ShieldCheck className="size-3.5 text-primary" aria-hidden="true" />
            أكاديمية عربية مجانية بالكامل
          </span>

          <h1 className="mt-7 text-5xl leading-[1.2] font-extrabold tracking-tight text-balance sm:text-6xl lg:text-7xl">
            من الصفر إلى
            <br />
            <span className="text-gradient">محترف أمن سيبراني</span>
          </h1>

          <p className="mt-7 max-w-xl text-lg leading-loose text-muted-foreground text-pretty">
            VORA تنظّم لك أفضل دورات يوتيوب العربية والعالمية في مسار واحد واضح، من أساسيات الحاسوب والشبكات حتى اختبار الاختراق وتحليل البرمجيات الخبيثة.
          </p>

          <div className="mt-10 flex flex-wrap gap-3">
            <a
              href="#courses"
              className="bg-gold group inline-flex h-13 items-center gap-2 rounded-xl px-7 font-bold text-primary-foreground shadow-[0_10px_40px_-10px] shadow-primary/60 ring-1 ring-white/20 transition-transform hover:-translate-y-0.5"
            >
              تصفح الدورات
              <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" aria-hidden="true" />
            </a>
            <a
              href="#roadmap"
              className="inline-flex h-13 items-center rounded-xl border border-border bg-card/50 px-7 font-semibold backdrop-blur transition-colors hover:border-primary/40 hover:bg-accent"
            >
              شاهد خارطة الطريق
            </a>
          </div>

          <dl className="mt-14 grid max-w-xl grid-cols-2 overflow-hidden rounded-2xl border border-border bg-card/40 backdrop-blur-xl sm:grid-cols-4">
            {STATS.map((s) => (
              <div key={s.label} className="border-border p-4 not-last:border-e max-sm:nth-[2]:border-e-0 max-sm:nth-[-n+2]:border-b">
                <dt className="text-xs text-muted-foreground">{s.label}</dt>
                <dd className="text-gradient mt-1 font-mono text-3xl font-bold">{s.value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>

      <TrackMarquee />
    </section>
  )
}

function TrackMarquee() {
  const items = [...TRACKS, ...TRACKS]
  return (
    <div className="relative border-y border-border bg-background/60 py-5 backdrop-blur [mask-image:linear-gradient(to_right,transparent,black_15%,black_85%,transparent)]">
      <div dir="ltr" className="animate-marquee flex w-max gap-12">
        {items.map((t, i) => (
          <span key={`${t.id}-${i}`} aria-hidden={i >= TRACKS.length} className="flex items-center gap-3 whitespace-nowrap font-mono text-sm tracking-widest text-muted-foreground uppercase">
            <span className="size-1.5 rotate-45 bg-primary" />
            {t.subtitle}
          </span>
        ))}
      </div>
    </div>
  )
}
