import { ArrowUpLeft } from "lucide-react"
import { SectionHeading } from "@/components/section-heading"
import { LEVELS, TRACKS, type Level } from "@/lib/courses"
import { cn } from "@/lib/utils"

const LEVEL_STYLE: Record<Level, { dot: string; text: string; blurb: string }> = {
  beginner: { dot: "bg-secondary", text: "text-secondary", blurb: "ابنِ الأساس: الحاسوب، الشبكات، لينكس والبرمجة." },
  intermediate: { dot: "bg-primary", text: "text-primary", blurb: "ادخل عالم الاختراق الأخلاقي واستعد لـ OSCP." },
  advanced: { dot: "bg-tertiary", text: "text-tertiary", blurb: "تخصص في الويب، Active Directory والتحليل الدفاعي." },
}

export function Roadmap() {
  let step = 0
  return (
    <section id="roadmap" className="scroll-mt-24 py-24">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeading
          eyebrow="خارطة الطريق"
          title="ثلاث مراحل. عشرة مسارات. طريق واحد واضح."
          description="اتبع المسارات بالترتيب. كل مرحلة تبني على ما قبلها حتى تصل إلى مستوى احترافي."
        />

        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {(Object.keys(LEVELS) as Level[]).map((lvl) => {
            const style = LEVEL_STYLE[lvl]
            const tracks = TRACKS.filter((t) => t.level === lvl)
            return (
              <div key={lvl} className="flex flex-col rounded-3xl border border-border bg-card/50 p-6">
                <div className="flex items-center justify-between">
                  <span className={cn("inline-flex items-center gap-2 text-sm font-bold", style.text)}>
                    <span className={cn("size-2 rounded-full", style.dot)} />
                    {LEVELS[lvl].label}
                  </span>
                  <span className="font-mono text-xs text-muted-foreground">{LEVELS[lvl].code}</span>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{style.blurb}</p>

                <ol className="mt-6 flex flex-col gap-2">
                  {tracks.map((t) => {
                    step += 1
                    return (
                      <li key={t.id}>
                        <a
                          href={`#track-${t.id}`}
                          className="group flex items-center gap-4 rounded-2xl border border-transparent bg-background/60 p-3 transition-colors hover:border-border hover:bg-accent"
                        >
                          <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-muted font-mono text-sm font-bold text-muted-foreground group-hover:text-foreground">
                            {String(step).padStart(2, "0")}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate font-semibold">{t.title}</span>
                            <span className="block text-xs text-muted-foreground">{t.courses.length} دورات</span>
                          </span>
                          <ArrowUpLeft className="size-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" aria-hidden="true" />
                        </a>
                      </li>
                    )
                  })}
                </ol>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
