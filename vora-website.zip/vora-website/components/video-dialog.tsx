"use client"

import { useEffect, useRef } from "react"
import { ExternalLink, X } from "lucide-react"
import { courseUrl, embedUrl, type Course } from "@/lib/courses"

export function VideoDialog({ course, onClose }: { course: Course | null; onClose: () => void }) {
  const ref = useRef<HTMLDialogElement>(null)

  useEffect(() => {
    const dialog = ref.current
    if (!dialog) return
    if (course && !dialog.open) dialog.showModal()
    if (!course && dialog.open) dialog.close()
  }, [course])

  return (
    <dialog
      ref={ref}
      onClose={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
      aria-labelledby="video-dialog-title"
      className="m-auto w-[min(1024px,94vw)] max-w-none overflow-hidden rounded-3xl border border-border bg-card p-0 text-foreground shadow-[0_0_140px_-30px] shadow-primary/60 backdrop:bg-background/85 backdrop:backdrop-blur-sm"
    >
      {course && (
        <div>
          <div className="flex items-center justify-between gap-4 border-b border-border px-5 py-3">
            <div className="min-w-0">
              <h3 id="video-dialog-title" className="truncate font-bold">
                {course.title}
              </h3>
              <p className="text-xs text-secondary">{course.instructor}</p>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <a
                href={courseUrl(course)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                <ExternalLink className="size-4" aria-hidden="true" />
                <span className="hidden sm:inline">يوتيوب</span>
              </a>
              <button
                type="button"
                onClick={onClose}
                className="rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                aria-label="إغلاق"
              >
                <X className="size-5" aria-hidden="true" />
              </button>
            </div>
          </div>
          <div className="aspect-video bg-background">
            <iframe
              src={embedUrl(course)}
              title={course.title}
              className="size-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          </div>
        </div>
      )}
    </dialog>
  )
}
