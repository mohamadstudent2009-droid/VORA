"use client"

import Image from "next/image"
import { ListVideo, Play, Sparkles } from "lucide-react"
import { usePlayer } from "@/components/player-provider"
import { FEATURED_COURSE, thumbUrl } from "@/lib/courses"

export function FeaturedCourse() {
  const play = usePlayer()
  const c = FEATURED_COURSE

  return (
    <section aria-labelledby="featured-title" className="relative px-5 py-24">
      <div aria-hidden="true" className="absolute inset-x-0 top-1/2 mx-auto h-72 max-w-4xl -translate-y-1/2 rounded-full bg-primary/10 blur-[120px]" />
      <article className="card-glow relative mx-auto grid max-w-7xl overflow-hidden rounded-[2rem] shadow-2xl shadow-black/60 lg:grid-cols-[1fr_1.15fr]">
        <div className="flex flex-col justify-center gap-6 p-8 md:p-12">
          <span className="inline-flex w-fit items-center gap-2 rounded-full bg-gold px-3 py-1 text-xs font-bold text-primary-foreground">
            <Sparkles className="size-3.5" aria-hidden="true" />
            جديد · ابدأ من هنا
          </span>
          <div>
            <p className="text-sm font-medium text-secondary" dir="auto">{c.instructor}</p>
            <h2 id="featured-title" className="mt-2 text-3xl font-extrabold text-balance md:text-4xl">{c.title}</h2>
            <p className="mt-4 leading-loose text-muted-foreground text-pretty">{c.description}</p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => play(c)}
              className="bg-gold inline-flex h-12 items-center gap-2 rounded-xl px-6 font-bold text-primary-foreground shadow-[0_10px_40px_-10px] shadow-primary/60 ring-1 ring-white/20 transition-transform hover:-translate-y-0.5"
            >
              <Play className="size-4 fill-current" aria-hidden="true" />
              ابدأ المشاهدة
            </button>
            <span className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-muted/60 px-3 py-3 text-sm text-muted-foreground">
              <ListVideo className="size-4" aria-hidden="true" />8 دروس
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => play(c)}
          className="group relative m-2 aspect-video overflow-hidden rounded-[1.5rem] lg:aspect-auto lg:min-h-[380px]"
          aria-label={`تشغيل ${c.title}`}
        >
          <Image
            src={thumbUrl(c) || "/placeholder.svg"}
            alt=""
            fill
            unoptimized
            className="object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <span className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent" />
          <span className="absolute inset-0 grid place-items-center">
            <span className="bg-gold relative grid size-18 place-items-center rounded-full text-primary-foreground shadow-2xl shadow-primary/50 transition-transform group-hover:scale-110">
              <span className="animate-pulse-ring absolute inset-0 rounded-full bg-primary" />
              <Play className="relative size-7 fill-current" aria-hidden="true" />
            </span>
          </span>
        </button>
      </article>
    </section>
  )
}
