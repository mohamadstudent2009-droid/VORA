import { cn } from "@/lib/utils"

export function VoraLogo({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)} dir="ltr">
      <span className="bg-gold relative grid size-8 place-items-center rounded-lg shadow-lg shadow-primary/25 ring-1 ring-white/20">
        <svg viewBox="0 0 24 24" className="size-4.5 text-primary-foreground" fill="none" aria-hidden="true">
          <path d="M4 5l8 14 8-14" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
      <span className="text-gradient font-mono text-lg font-bold tracking-[0.3em]">VORA</span>
    </span>
  )
}
