export function SectionHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return (
    <div className="max-w-2xl">
      <p className="text-sm font-semibold text-primary">{eyebrow}</p>
      <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-balance md:text-4xl">{title}</h2>
      <p className="mt-4 leading-relaxed text-muted-foreground text-pretty">{description}</p>
    </div>
  )
}
