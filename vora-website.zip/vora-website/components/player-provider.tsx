"use client"

import { createContext, useContext, useState } from "react"
import { VideoDialog } from "@/components/video-dialog"
import type { Course } from "@/lib/courses"

const PlayerContext = createContext<(course: Course) => void>(() => {})

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const [playing, setPlaying] = useState<Course | null>(null)
  return (
    <PlayerContext.Provider value={setPlaying}>
      {children}
      <VideoDialog course={playing} onClose={() => setPlaying(null)} />
    </PlayerContext.Provider>
  )
}

export function usePlayer() {
  return useContext(PlayerContext)
}
