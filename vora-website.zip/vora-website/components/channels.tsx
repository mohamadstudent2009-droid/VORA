import { ArrowUpLeft } from "lucide-react"
import { CHANNELS } from "@/lib/courses"
import { SectionHeading } from "@/components/section-heading"

export function Channels() {
  return (
    <section id="channels" className="scroll-mt-24 py-24">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeading
          eyebrow="قنوات مختارة"
          title="تابع نخبة صنّاع المحتوى"
          description="قنوات عربية وعالمية في الأمن السيبراني و CTF والـ Bug Bounty لتواصل التعلم بعد إنهاء المسار."
        />

        <ul className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {CHANNELS.map((ch) => (
            <li key={ch.handle}>
              <a
                href={`https://www.youtube.com/@${ch.handle}`}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex h-full flex-col rounded-3xl border border-border bg-card/50 p-5 transition-all hover:-translate-y-1 hover:border-primary/40"
              >
                <div className="flex items-start justify-between">
                  <span className="grid size-11 place-items-center rounded-2xl bg-gradient-to-br from-primary/30 to-secondary/20 font-mono text-lg font-bold">
                    {ch.name.charAt(0)}
                  </span>
                  <ArrowUpLeft className="size-4 text-muted-foreground transition-colors group-hover:text-primary" aria-hidden="true" />
                </div>
                <p className="mt-4 text-start font-bold" dir="ltr">{ch.name}</p>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{ch.description}</p>
                <span className="mt-4 w-fit rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">
                  {ch.lang === "ar" ? "عربي" : "إنجليزي"}
                </span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
