import { VoraLogo } from "@/components/vora-logo"

const NAV = [
  { href: "#roadmap", label: "خارطة الطريق" },
  { href: "#courses", label: "الدورات" },
  { href: "#channels", label: "القنوات" },
]

export function SiteHeader() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 px-4 pt-4">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between rounded-2xl border border-border bg-background/60 px-3 ps-4 shadow-2xl shadow-black/40 backdrop-blur-2xl backdrop-saturate-150">
        <a href="#top" aria-label="VORA - الصفحة الرئيسية">
          <VoraLogo />
        </a>
        <nav aria-label="التنقل الرئيسي" className="hidden md:block">
          <ul className="flex items-center gap-1">
            {NAV.map((n) => (
              <li key={n.href}>
                <a
                  href={n.href}
                  className="rounded-lg px-4 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                >
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <a
          href="#courses"
          className="bg-gold rounded-xl px-4 py-2 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/20 transition-opacity hover:opacity-90"
        >
          ابدأ مجاناً
        </a>
      </div>
    </header>
  )
}
